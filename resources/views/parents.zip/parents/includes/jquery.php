 <script src="../assets/js/jquery-3.3.1.min.js"></script>
 <!-- Plugins js -->
 <script src="../assets/js/plugins.js"></script>
 <!-- Popper js -->
 <script src="../assets/js/popper.min.js"></script>
 <!-- Bootstrap js -->
 <script src="../assets/js/bootstrap.min.js"></script>
 <!-- Counterup Js -->
 <script src="../assets/js/jquery.counterup.min.js"></script>
 <!-- Waypoints Js -->
 <script src="../assets/js/jquery.waypoints.min.js"></script>
 <!-- Scroll Up Js -->
 <script src="../assets/js/jquery.scrollUp.min.js"></script>
 <!-- Data Table Js -->
 <script src="../assets/js/jquery.dataTables.min.js"></script>
 <!-- Custom Js -->
 <script src="../assets/js/main.js"></script>